# LiFi Wormhole SDK Route

This package implements an AutomaticRoute for use with the Wormhole TypeScript SDK using LI.FI as the bridge aggregator.

## Overview

LI.FI is a cross-chain bridge aggregator that enables seamless token transfers across multiple blockchain networks. This implementation provides a Wormhole SDK Route interface that leverages LI.FI's aggregation capabilities to find the best routes for cross-chain transfers.

## Features

- **Multi-chain Support**: Supports transfers between major EVM chains including Ethereum, Polygon, BSC, Avalanche, Arbitrum, Optimism, and Base
- **Solana Support**: Basic Solana transaction execution support
- **Route Optimization**: Automatically finds the best routes through LI.FI's aggregation of multiple bridges and DEXs
- **Direct Transaction Execution**: Takes LiFi transaction data and signs it directly with Wormhole SDK signers
- **Token Approvals**: Handles ERC-20 token approvals using Wormhole SDK patterns
- **Transaction Tracking**: Real-time tracking of cross-chain transfer status
- **Wormhole SDK Integration**: Seamlessly integrates with the Wormhole SDK ecosystem

## Installation

```bash
npm install @lifi/wormhole-sdk-route
```

## Usage

```typescript
import { Wormhole, routes } from "@wormhole-foundation/sdk-connect";
import { EvmPlatform } from "@wormhole-foundation/sdk-evm";
import { LiFiRoute } from "@lifi/wormhole-sdk-route";

// Setup
const wh = new Wormhole("Mainnet", [EvmPlatform]);
const resolver = wh.resolver([LiFiRoute]);

// Create transfer request
const tr = await routes.RouteTransferRequest.create(wh, {
  source: Wormhole.tokenId("Ethereum", "native"),
  destination: Wormhole.tokenId("Polygon", "native"),
});

// Find routes
const foundRoutes = await resolver.findRoutes(tr);
const bestRoute = foundRoutes[0];

// Get quote
const quote = await bestRoute.quote(tr, {
  amount: "0.01",
  options: bestRoute.getDefaultOptions(),
});

// Execute transfer
const receipt = await bestRoute.initiate(
  tr,
  signer,
  quote,
  destinationAddress
);

// Track transfer
for await (const update of bestRoute.track(receipt)) {
  console.log("Transfer status:", update.state);
}
```

## How It Works

The LiFi route implementation bridges the gap between LI.FI's aggregation system and Wormhole SDK's signing patterns:

1. **Quote Fetching**: Uses LI.FI's API to get quotes for cross-chain transfers
2. **Route Conversion**: Converts LI.FI quotes to executable routes
3. **Direct Transaction Execution**: For each step in the route:
   - Extracts transaction data from LI.FI step
   - Creates Wormhole SDK transaction format
   - Signs and sends using Wormhole SDK signer patterns
4. **Token Approvals**: Handles ERC-20 approvals automatically using Wormhole SDK patterns
5. **Transaction Tracking**: Monitors transaction status through LI.FI's tracking system

## Configuration Options

The LiFi route supports the following configuration options:

- `slippage`: Maximum slippage tolerance (default: 0.5%)
- `maxPriceImpact`: Maximum price impact allowed (default: 20%)
- `allowDestinationCall`: Allow contract calls on destination chain (default: false)
- `integrator`: Integrator identifier for analytics (default: "wormhole-sdk")
- `referrer`: Referrer address for fee sharing
- `fee`: Fee percentage for integrator

## Supported Chains

### Mainnet
- Ethereum
- Polygon
- Binance Smart Chain
- Avalanche
- Arbitrum
- Optimism
- Base

### Testnet
- Ethereum Goerli/Sepolia
- Polygon Mumbai
- BSC Testnet
- Avalanche Fuji
- Arbitrum Goerli
- Optimism Goerli
- Base Goerli

## Examples

See the `examples/` directory for complete usage examples.

## Development

```bash
# Install dependencies
npm install

# Build the project
npm run build

# Run example
npm run example:swap
```

## License

Apache-2.0